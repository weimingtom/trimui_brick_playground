C
^

Simple Line meter
""""""""""""""""""

.. image:: /lv_examples/src/lv_ex_widgets/lv_ex_linemeter/lv_ex_linemeter_1.*
  :alt: Line meter example in LittlevGL

.. container:: toggle

    .. container:: header
    
      code

    .. literalinclude:: /lv_examples/src/lv_ex_widgets/lv_ex_linemeter/lv_ex_linemeter_1.c
      :language: c

MicroPython
^^^^^^^^^^^

No examples yet.
