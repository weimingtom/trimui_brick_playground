C
^
Simple Bar 
""""""""""""""""

.. image:: /lv_examples/src/lv_ex_widgets/lv_ex_bar/lv_ex_bar_1.*
  :alt: Bar example in LittlevGL

.. container:: toggle

    .. container:: header
    
      code

    .. literalinclude:: /lv_examples/src/lv_ex_widgets/lv_ex_bar/lv_ex_bar_1.c
      :language: c

MicroPython
^^^^^^^^^^^

No examples yet.
