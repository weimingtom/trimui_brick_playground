C
^

Simple List 
""""""""""""""""

.. image:: /lv_examples/src/lv_ex_widgets/lv_ex_list/lv_ex_list_1.*
  :alt: List example in LittlevGL

.. container:: toggle

    .. container:: header
    
      code

    .. literalinclude:: /lv_examples/src/lv_ex_widgets/lv_ex_list/lv_ex_list_1.c
      :language: c

MicroPython
^^^^^^^^^^^

No examples yet.
