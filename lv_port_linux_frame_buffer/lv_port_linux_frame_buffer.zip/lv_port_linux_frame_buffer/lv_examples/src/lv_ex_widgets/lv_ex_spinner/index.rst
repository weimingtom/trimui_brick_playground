C
^

Simple spinner 
""""""""""""""""""""""""""""

.. image:: /lv_examples/src/lv_ex_widgets/lv_ex_spinner/lv_ex_spinner_1.*
  :alt: Spinner example in LittlevGL

.. container:: toggle

    .. container:: header
    
      code

    .. literalinclude:: /lv_examples/src/lv_ex_widgets/lv_ex_spinner/lv_ex_spinner_1.c
      :language: c

MicroPython
^^^^^^^^^^^
